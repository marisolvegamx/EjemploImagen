package com.example.ejemploimagen;


import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName="imagenes")
    public class Imagen {
        @PrimaryKey(autoGenerate = true)
        @NonNull

        private int   id_idimagen;
        @NonNull

        private int id_reporte;
        @NonNull

        private String id_ruta;

        private String id_descripcion;

        private int estatus;

    public int getId_idimagen() {
        return id_idimagen;
    }

    public void setId_idimagen(int id_idimagen) {
        this.id_idimagen = id_idimagen;
    }

    public int getId_reporte() {
        return id_reporte;
    }

    public void setId_reporte(int id_reporte) {
        this.id_reporte = id_reporte;
    }

    @NonNull
    public String getId_ruta() {
        return id_ruta;
    }

    public int getEstatus() {
        return estatus;
    }

    public void setEstatus(int estatus) {
        this.estatus = estatus;
    }

    public void setId_ruta(@NonNull String id_ruta) {
        this.id_ruta = id_ruta;
    }

    public String getId_descripcion() {
        return id_descripcion;
    }

    public void setId_descripcion(String id_descripcion) {
        this.id_descripcion = id_descripcion;
    }

}