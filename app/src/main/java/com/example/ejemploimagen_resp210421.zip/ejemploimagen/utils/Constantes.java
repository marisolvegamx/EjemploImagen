package com.example.ejemploimagen.utils;

public class Constantes {
    public static final String ESTADO = "estado";
    public static final String MENSAJE = "mensaje";
    public static final String ID_GASTO = "idGasto";

    public static final String GET_URL ="https://muesmerc.mx/postmixv3/api/Subirfotos.php" ;
    public static final String SUCCESS ="1" ;
    public static final String FAILED = "2";
    public static final String INSERT_URL ="https://muesmerc.mx/postmixv3/api/Subirfotos.php" ;
    public static final String ACCOUNT_TYPE ="com.example.ejemploimagen.account" ;
}
