package com.example.ejemploimagen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import com.example.ejemploimagen.database.Injection;
import com.example.ejemploimagen.sync.SyncAdapter;
import com.example.ejemploimagen.ui.ReporteViewModel;
import com.example.ejemploimagen.ui.ViewModelFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class Actividad2 extends AppCompatActivity {

    private ListView lv1;
    private ImageView im1;
    private String[] archivos;
    private ArrayAdapter<String> adaptador;
    List<String> reportesg;
    List<Reporte> reportes;
    private static final String TAG = MainActivity.class.getSimpleName();
    private ReporteViewModel mViewModel;
    private ViewModelFactory mViewModelFactory;
    private final CompositeDisposable mDisposable = new CompositeDisposable();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad2);
      //  File dir=getExternalFilesDir(null);
        //archivos=dir.list();


        lv1=(ListView)findViewById(R.id.listview);

        im1=(ImageView) findViewById(R.id.imageView2);
        mViewModelFactory = Injection.provideViewModelFactory(this);
        mViewModel = new ViewModelProvider(this, mViewModelFactory).get(ReporteViewModel.class);

      /*  lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Bitmap bitmap1= BitmapFactory.decodeFile(getExternalFilesDir(null)+"/"+archivos[i]);
                im1.setImageBitmap(bitmap1);
            }
        });
*/


    }
    @Override
    protected void onStart() {
        super.onStart();
        // Subscribe to the emissions of the user name from the view model.
        // Update the user name text view, at every onNext emission.
        // In case of error, log the exception.
             mDisposable.add(mViewModel.getReportesPendientes()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<List<Reporte>>() {

                               @Override
                               public void accept(List<Reporte> repo)  {
                                   System.out.print(repo);
                                   reportes=new ArrayList<Reporte>();
                                   if(repo!=null) {
                                       reportes.addAll(repo);
                                       mDisposable.add(mViewModel.getImagenesPendientes()
                                               .subscribeOn(Schedulers.io())
                                               .observeOn(AndroidSchedulers.mainThread())
                                               .subscribe(new Consumer<List<Imagen>>() {

                                                              @Override
                                                              public void accept(List<Imagen> tasks)  {
                                                                  llenarLista(tasks);
                                                              }
                                                          },
                                                       throwable -> Log.e(TAG, "Unable to get username", throwable)));

                                   }
                               }
                           },
                        throwable -> Log.e(TAG, "Unable to get username", throwable)));
    }

    private  void llenarLista(List<Imagen> reportes){
    reportesg=new ArrayList<>();
        reportesg.clear();
        for (Imagen imagen: reportes ) {
            //busco en reportes
            Reporte reporte= buscarReporte(imagen);
            if(reporte!=null)
             reportesg.add(reporte.getId()+" "+reporte.getUbicacion()+" "+imagen.getId_idimagen()+" "+imagen.getId_reporte()+" "+imagen.getId_ruta()+" "+imagen.getId_descripcion()+" "+imagen.getEstatus());
        }
        adaptador = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, reportesg);

        //  reportesg.addAll(reportes);
        adaptador.notifyDataSetChanged();

        lv1.setAdapter(adaptador);
    }

    private Reporte buscarReporte(Imagen im){
        if(reportes!=null)
        for(Reporte rep:reportes){
            if(im.getId_reporte()==rep.getId()){
                return rep;
            }
        }
        return null;
    }

}